Place The Files inside C:\Windows\SystemApps\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy
and add one dword-32 in [Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced] named [Start_ShowClassicMode] and set it to 1

The start menu will be slow, when the start menu closes.